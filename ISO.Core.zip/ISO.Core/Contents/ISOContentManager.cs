﻿using Microsoft.Xna.Framework.Content;
using System;
using System.Collections.Generic;
using System.IO;
using System.IO.Compression;
using System.Text;

namespace ISO.Core.Contents
{
    public class ISOContentManager : ContentManager
    {
        public ISOContentManager(IServiceProvider provider) : base(provider)
        {

        }

        protected override Stream OpenStream(string assetName)
        {
            Stream stream = null;

            using (ZipArchive zip = ZipFile.Open(assetName, ZipArchiveMode.Read))
            {                
                foreach (ZipArchiveEntry entry in zip.Entries)
                    if (entry.FullName == assetName)                        
                        stream =  entry.Open();
                
            }

          return stream;

        }
    }
}
